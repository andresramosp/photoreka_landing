-- ApiService.lua - Servicio de comunicación con la API de Photoreka
local LrTasks = import 'LrTasks'
local LrHttp = import 'LrHttp'
local LrFileUtils = import 'LrFileUtils'
local LrPathUtils = import 'LrPathUtils'
local LrDialogs = import 'LrDialogs'
local LrLogger = import 'LrLogger'

local JSON = require 'JSON'
local Config = require 'Config'
local AuthService = require 'AuthService'

local ApiService = {}

-- Configurar logger
local log = LrLogger('PhotorekaPlugin')
log:enable("logfile")

log:info("ApiService cargado. API_BASE_URL: " .. Config.API_BASE_URL)

-- Obtiene el token de autenticación (desde AuthService)
-- Retorna: token string o genera error si no se puede autenticar
local function getAuthToken()
    local token = AuthService.ensureAuthenticated()
    
    if not token or token == '' then
        error("No se pudo obtener el token de autenticación. El usuario canceló el login.")
    end
    
    return token
end

-- Lee un archivo como datos binarios
-- Parámetros:
--   filePath: ruta absoluta al archivo
-- Retorna: contenido del archivo como string binario
local function readFileAsBinary(filePath)
    local file = io.open(filePath, "rb")
    if not file then
        error("No se pudo abrir el archivo: " .. filePath)
    end
    local fileData = file:read("*all")
    file:close()
    return fileData
end

-- Obtiene el nombre del archivo de una ruta
-- Parámetros:
--   filePath: ruta completa del archivo
-- Retorna: nombre del archivo
local function getFileName(filePath)
    return LrPathUtils.leafName(filePath)
end

-- Sube un archivo a Cloudflare R2 con reintentos
-- Parámetros:
--   url: URL firmada de R2
--   filePath: ruta del archivo a subir
--   fileType: tipo MIME (ej: "image/jpeg")
--   maxRetries: número máximo de reintentos
-- Retorna: true si éxito, error si falla
local function uploadToR2WithRetry(url, filePath, fileType, maxRetries)
    maxRetries = maxRetries or Config.MAX_RETRIES
    
    -- Leer el archivo una sola vez
    log:info("Leyendo archivo: " .. tostring(filePath))
    local fileData = readFileAsBinary(filePath)
    local fileName = getFileName(filePath)
    log:info("Archivo leído, tamaño: " .. tostring(string.len(fileData)) .. " bytes")
    
    for attempt = 1, maxRetries do
        log:info(string.format("Intento %d de %d para subir %s", attempt, maxRetries, fileName))
        
        -- Preparar headers
        local headers = {
            { field = "Content-Type", value = fileType }
        }
        
        -- Hacer PUT request
        log:info("Haciendo PUT a R2...")
        local response, responseHeaders = LrHttp.post(url, fileData, headers, "PUT")
        
        if response and responseHeaders then
            -- Verificar código de estado
            local statusCode = tonumber(responseHeaders.status)
            log:info("R2 Response status: " .. tostring(statusCode))
            
            if statusCode and statusCode >= 200 and statusCode < 300 then
                log:info("Upload exitoso!")
                return true  -- Éxito
            else
                log:error(string.format("R2 error %d: %s", statusCode or 0, tostring(response)))
            end
        else
            log:error("No response from R2")
        end
        
        -- Si no fue exitoso y no es el último intento, esperar con backoff exponencial
        if attempt < maxRetries then
            local delay = math.pow(2, attempt)  -- 2s, 4s, 8s
            log:info("Esperando " .. tostring(delay) .. " segundos antes de reintentar...")
            LrTasks.sleep(delay)
        end
    end
    
    log:error(string.format("Failed to upload %s after %d attempts", fileName, maxRetries))
    error(string.format("Failed to upload %s after %d attempts", fileName, maxRetries))
end

-- Solicita URLs firmadas al backend para una foto
-- Parámetros:
--   originalName: nombre original del archivo
--   exifData: tabla con metadatos EXIF
--   sourceData: tabla con información de origen {type, uniqueId}
-- Retorna: tabla con {uploadUrl, thumbnailUploadUrl, photo}
local function requestUploadUrls(originalName, exifData, sourceData)
    local token = getAuthToken()
    
    local url = Config.API_BASE_URL .. "/api/catalog/uploadPhoto"
    
    local payload = {
        fileType = "image/jpeg",
        originalName = originalName,
        source = sourceData,
        exifData = exifData
    }
    
    log:info("Preparando request a: " .. url)
    
    local headers = {
        { field = "Authorization", value = "Bearer " .. token },
        { field = "Content-Type", value = "application/json" }
    }
    
    local body = JSON.encode(payload)
    log:info("Body JSON length: " .. tostring(string.len(body)))
    
    local response, responseHeaders = LrHttp.post(url, body, headers)
    
    if not response then
        log:error("ERROR: No response from server")
        error("Failed to get upload URLs from server")
    end
    
    log:info("Response recibida, length: " .. tostring(string.len(response)))
    
    -- Verificar código de estado
    if responseHeaders and responseHeaders.status then
        local statusCode = tonumber(responseHeaders.status)
        log:info("Status code: " .. tostring(statusCode))
        
        if statusCode and (statusCode < 200 or statusCode >= 300) then
            log:error("Server error " .. tostring(statusCode) .. ": " .. tostring(response))
            
            -- Detectar error de email no confirmado
            if statusCode == 403 and response then
                local success, errorData = pcall(function() return JSON.decode(response) end)
                if success and errorData and errorData.code == "EMAIL_NOT_CONFIRMED" then
                    -- Mostrar diálogo al usuario
                    LrDialogs.message(
                        "Email Not Confirmed",
                        "Please confirm your email address before uploading photos. Check your inbox for the confirmation email from Photoreka.",
                        "info"
                    )
                    error("Email not confirmed. Please check your inbox and confirm your email address.")
                end
            end
            
            error(string.format("Server returned error %d: %s", statusCode, response or "unknown error"))
        end
    end
    
    log:info("Decodificando JSON response...")
    local responseData = JSON.decode(response)
    log:info("JSON decodificado OK")
    
    return responseData
end

-- Procesa y sube una foto individual (main + thumbnail)
-- Parámetros:
--   mainImagePath: ruta al archivo principal (1500px)
--   thumbnailPath: ruta al thumbnail (800px)
--   exifData: metadatos EXIF
--   sourceData: tabla con información de origen {type, uniqueId}
-- Retorna: tabla con información de la foto subida
local function processAndUploadPhoto(mainImagePath, thumbnailPath, exifData, sourceData)
    local originalName = getFileName(mainImagePath)
    
    -- LOG: Inicio del proceso
    log:info("===== PROCESANDO FOTO =====")
    log:info("Nombre: " .. tostring(originalName))
    log:info("Path main: " .. tostring(mainImagePath))
    log:info("Path thumb: " .. tostring(thumbnailPath))
    
    -- 1. Solicitar URLs firmadas
    log:info("PASO 1: Solicitando URLs firmadas...")
    local uploadData = requestUploadUrls(originalName, exifData, sourceData)
    
    log:info("URLs recibidas OK")
    log:info("Upload URL: " .. tostring(uploadData.uploadUrl))
    log:info("Thumb URL: " .. tostring(uploadData.thumbnailUploadUrl))
    
    if not uploadData.uploadUrl or not uploadData.thumbnailUploadUrl then
        log:error("ERROR: Server did not return upload URLs")
        error("Server did not return upload URLs")
    end
    
    -- 2. Subir archivo principal a R2
    log:info("PASO 2: Subiendo imagen principal...")
    uploadToR2WithRetry(
        uploadData.uploadUrl,
        mainImagePath,
        "image/jpeg",
        Config.MAX_RETRIES
    )
    
    log:info("Imagen principal subida OK")
    
    -- 3. Subir thumbnail a R2
    log:info("PASO 3: Subiendo thumbnail...")
    uploadToR2WithRetry(
        uploadData.thumbnailUploadUrl,
        thumbnailPath,
        "image/jpeg",
        Config.MAX_RETRIES
    )
    
    log:info("Thumbnail subido OK")
    log:info("===== FOTO COMPLETADA =====")
    
    return uploadData.photo
end

-- Trigger de post-procesamiento en el backend
-- Se debe llamar UNA VEZ después de subir todas las fotos
-- Parámetros:
--   photoIds: array de IDs de fotos subidas exitosamente
local function triggerProcess(photoIds)
    local token = getAuthToken()
    
    local url = Config.ANALYZER_API_BASE_URL .. "/api/analyzer"
    
    local payload = {
        packageId = "process",
        mode = "adding",
        photoIds = photoIds
    }
    
    local headers = {
        { field = "Authorization", value = "Bearer " .. token },
        { field = "Content-Type", value = "application/json" }
    }
    
    local body = JSON.encode(payload)
    local response, responseHeaders = LrHttp.post(url, body, headers)
    
    if not response then
        error("Failed to trigger preprocessing")
    end
    
    return true
end

-- Procesa fotos con límite de concurrencia (similar a p-limit)
-- Parámetros:
--   tasks: array de funciones que retornan el resultado de procesar cada foto
--   limit: número máximo de tareas simultáneas
--   progressCallback: función de progreso
--   totalPhotos: total de fotos para el callback
-- Retorna: array de resultados {success = true/false, result = data/error}
local function processWithConcurrencyLimit(tasks, limit, progressCallback, totalPhotos)
    local results = {}
    local completed = 0
    local activeTasks = {}
    local nextTaskIndex = 1
    local totalTasks = #tasks
    
    log:info(string.format("Iniciando procesamiento concurrente: %d tareas, límite: %d", totalTasks, limit))
    
    -- Función para iniciar una nueva tarea
    local function startNextTask()
        if nextTaskIndex > totalTasks then
            return false -- No hay más tareas
        end
        
        local taskIndex = nextTaskIndex
        nextTaskIndex = nextTaskIndex + 1
        
        log:info(string.format("Iniciando tarea %d de %d", taskIndex, totalTasks))
        
        -- Crear y lanzar la tarea asíncrona
        local task = LrTasks.startAsyncTask(function()
            local success, result = LrTasks.pcall(tasks[taskIndex])
            
            -- Guardar resultado
            results[taskIndex] = {
                success = success,
                result = result
            }
            
            completed = completed + 1
            
            if progressCallback then
                progressCallback(
                    completed,
                    totalPhotos,
                    string.format('Synchronizing photo %d de %d...', completed, totalPhotos)
                )
            end
            
            log:info(string.format("Task %d completed (%d/%d)", taskIndex, completed, totalTasks))
            
            -- Marcar esta tarea como completada
            for i, t in ipairs(activeTasks) do
                if t.index == taskIndex then
                    table.remove(activeTasks, i)
                    break
                end
            end
            
            -- Iniciar la siguiente tarea si hay espacio
            if #activeTasks < limit then
                startNextTask()
            end
        end)
        
        table.insert(activeTasks, {index = taskIndex, task = task})
        return true
    end
    
    -- Iniciar las primeras N tareas (hasta el límite)
    for i = 1, math.min(limit, totalTasks) do
        startNextTask()
    end
    
    -- Esperar a que todas las tareas se completen
    while completed < totalTasks do
        LrTasks.sleep(0.1) -- Pequeña pausa para no saturar CPU
    end
    
    log:info(string.format("Procesamiento concurrente completado: %d/%d tareas", completed, totalTasks))
    
    return results
end

-- FUNCIÓN PRINCIPAL: Sube fotos a la API de Photoreka
-- Parámetros:
--   photoData: tabla con {fullPhotos = {...}, thumbPhotos = {...}, exifDataList = {...}, sourceDataList = {...}}
--   progressCallback: función que recibe (current, total, caption)
--   onlyToLightbox: booleano, si es true no se llama a triggerProcess
-- Retorna: tabla con {successfulUploads = {...}, failedUploads = {...}}
function ApiService.uploadPhotos(photoData, progressCallback, onlyToLightbox)
    onlyToLightbox = onlyToLightbox or false
    local fullPhotos = photoData.fullPhotos or {}
    local thumbPhotos = photoData.thumbPhotos or {}
    local exifDataList = photoData.exifDataList or {}
    local sourceDataList = photoData.sourceDataList or {}
    local totalPhotos = #fullPhotos
    
    log:info("========================================")
    log:info("INICIANDO SUBIDA DE FOTOS CON CONCURRENCIA")
    log:info("Total fotos: " .. tostring(totalPhotos))
    log:info("Full photos: " .. tostring(#fullPhotos))
    log:info("Thumb photos: " .. tostring(#thumbPhotos))
    log:info("EXIF data: " .. tostring(#exifDataList))
    log:info("Only to Lightbox: " .. tostring(onlyToLightbox))
    log:info("Concurrent uploads: " .. tostring(Config.CONCURRENT_UPLOADS))
    log:info("========================================")
    
    -- Validar que los arrays tengan la misma longitud
    if #thumbPhotos ~= totalPhotos then
        log:error("ERROR: Mismatch en cantidad de fotos!")
        error("Mismatch: fullPhotos and thumbPhotos must have the same length")
    end
    
    local successfulUploads = {}
    local failedUploads = {}
    
    -- Crear array de tareas (una por foto)
    local tasks = {}
    for i = 1, totalPhotos do
        tasks[i] = function()
            log:info("")
            log:info("========================================")
            log:info(string.format("PROCESANDO FOTO %d de %d", i, totalPhotos))
            log:info("========================================")
            
            -- Obtener EXIF data (ya extraída en Main.lua)
            local exifData = exifDataList[i]
            if not exifData then
                log:error("CRITICAL: No EXIF data para foto " .. tostring(i))
                error("Missing EXIF data for photo " .. tostring(i))
            end
            
            -- Obtener source data
            local sourceData = sourceDataList[i]
            if not sourceData then
                log:warn("No source data para foto " .. tostring(i) .. ", usando default")
                sourceData = { type = "lightroom", uniqueId = nil }
            end
            
            -- Procesar y subir foto
            return processAndUploadPhoto(
                fullPhotos[i],
                thumbPhotos[i],
                exifData,
                sourceData
            )
        end
    end
    
    -- Procesar fotos con límite de concurrencia
    local results = processWithConcurrencyLimit(
        tasks,
        Config.CONCURRENT_UPLOADS,
        progressCallback,
        totalPhotos
    )
    
    -- Procesar resultados
    for i, result in ipairs(results) do
        if result.success then
            log:info("✓ Foto " .. tostring(i) .. " subida exitosamente")
            table.insert(successfulUploads, result.result)
        else
            log:error("✗ Foto " .. tostring(i) .. " FALLÓ: " .. tostring(result.result))
            table.insert(failedUploads, {
                mainPath = fullPhotos[i],
                thumbPath = thumbPhotos[i],
                error = tostring(result.result)
            })
        end
    end
    
    log:info("")
    log:info("========================================")
    log:info("RESUMEN DE SUBIDA")
    log:info("Exitosas: " .. tostring(#successfulUploads))
    log:info("Fallidas: " .. tostring(#failedUploads))
    log:info("========================================")
    
    -- Si hubo éxitos Y NO es solo para lightbox, trigger preprocessing
    if #successfulUploads > 0 and not onlyToLightbox then
        log:info("Triggering preprocessing...")
        
        -- Extraer IDs de las fotos subidas exitosamente
        local photoIds = {}
        for _, photo in ipairs(successfulUploads) do
            if photo.id then
                table.insert(photoIds, photo.id)
            end
        end
        
        log:info("Photo IDs para preprocessing: " .. JSON.encode(photoIds))
        
        local success, result = LrTasks.pcall(function()
            return triggerProcess(photoIds)
        end)
        if not success then
            -- Log error pero no fallar el proceso completo
            log:error("Warning: Failed to trigger preprocessing - " .. tostring(result))
            print("Warning: Failed to trigger preprocessing - " .. tostring(result))
        else
            log:info("Preprocessing triggered OK")
        end
    elseif onlyToLightbox then
        log:info("Modo 'Only to Lightbox' activado - no se ejecuta preprocessing")
    end
    
    return {
        successfulUploads = successfulUploads,
        failedUploads = failedUploads
    }
end

-- Realiza una búsqueda semántica en el catálogo de Photoreka
-- Parámetros:
--   query: texto de búsqueda del usuario
--   searchMode: modo de búsqueda ("broad", "adaptive", "precise") - opcional, por defecto "adaptive"
-- Retorna: tabla con resultados de búsqueda
function ApiService.search(query, searchMode)
    local token = getAuthToken()
    
    -- Usar searchMode recibido o "adaptive" por defecto
    searchMode = searchMode or "adaptive"
    
    -- Opciones de búsqueda
    local searchOptions = {
        iteration = 1,
        pageSize = 100,
        searchMode = searchMode,
        collections = {},
        visualAspects = {},
        artisticScores = {},
        cursor = nil,
        source = 'lightroom'
    }
    
    local url = Config.API_BASE_URL .. "/api/search/semantic/sync"
    
    local payload = {
        description = query,
        options = searchOptions
    }
    
    log:info("Realizando búsqueda semántica: " .. query)
    log:info("URL: " .. url)
    
    local headers = {
        { field = "Authorization", value = "Bearer " .. token },
        { field = "Content-Type", value = "application/json" }
    }
    
    local body = JSON.encode(payload)
    local response, responseHeaders = LrHttp.post(url, body, headers)
    
    if not response then
        log:error("ERROR: No response from search API")
        error("Failed to get search results from server")
    end
    
    -- Verificar código de estado
    if responseHeaders and responseHeaders.status then
        local statusCode = tonumber(responseHeaders.status)
        log:info("Search API status code: " .. tostring(statusCode))
        
        if statusCode and (statusCode < 200 or statusCode >= 300) then
            log:error("Search API error " .. tostring(statusCode) .. ": " .. tostring(response))
            error(string.format("Search API returned error %d: %s", statusCode, response or "unknown error"))
        end
    end
    
    log:info("Decodificando resultados de búsqueda...")
    local searchResults = JSON.decode(response)
    log:info("Resultados obtenidos: " .. tostring(#(searchResults.results or {})) .. " fotos")
    
    return searchResults
end

-- Crea un token handoff efímero para exportar fotos a Photoreka
-- Retorna: string con el token handoff o nil si falla
function ApiService.createHandoff()
    local token = getAuthToken()
    
    local url = Config.API_BASE_URL .. "/api/auth_lr/create-handoff"
    
    log:info("Solicitando handoff token...")
    log:info("URL: " .. url)
    
    local headers = {
        { field = "Authorization", value = "Bearer " .. token },
        { field = "Content-Type", value = "application/json" }
    }
    
    local body = JSON.encode({})
    local response, responseHeaders = LrHttp.post(url, body, headers)
    
    if not response then
        log:error("ERROR: No response from handoff API")
        return nil
    end
    
    -- Verificar código de estado
    if responseHeaders and responseHeaders.status then
        local statusCode = tonumber(responseHeaders.status)
        log:info("Handoff API status code: " .. tostring(statusCode))
        
        if statusCode and (statusCode < 200 or statusCode >= 300) then
            log:error("Handoff API error " .. tostring(statusCode) .. ": " .. tostring(response))
            return nil
        end
    end
    
    log:info("Decodificando handoff response...")
    local responseData = JSON.decode(response)
    
    if responseData and responseData.handoffToken then
        log:info("Handoff token obtenido exitosamente")
        return responseData.handoffToken
    else
        log:error("Handoff response no contiene handoffToken")
        return nil
    end
end

return ApiService

-- FolderPathService.lua - Extracts folder hierarchy from a photo using
-- the Lightroom catalog folder tree. The result is used by Photoreka to
-- mirror Lightroom folder structure into Photoreka collections.
local LrPathUtils = import 'LrPathUtils'
local LrLogger = import 'LrLogger'

local FolderPathService = {}

local log = LrLogger('PhotorekaPlugin')
log:enable("logfile")

-- Splits a filesystem path into segments (handles both / and \).
local function splitSegments(path)
    local parts = {}
    if not path or path == '' then return parts end
    for segment in path:gmatch('[^\\/]+') do
        if segment ~= '' then
            table.insert(parts, segment)
        end
    end
    return parts
end

-- Attempts to obtain the file system path for a photo using multiple strategies.
-- Must be called from within catalog:withReadAccessDo() or equivalent.
local function getPhotoFilePath(photo)
    -- Strategy 1: direct 'path' raw metadata key (most common)
    local ok, v = pcall(function()
        return photo:getRawMetadata('path')
    end)
    if ok and type(v) == 'string' and v ~= '' then
        log:info('FolderPathService: got path via "path" key: ' .. v)
        return v
    end
    log:info('FolderPathService: "path" key returned: ok=' .. tostring(ok) .. ' v=' .. tostring(v))

    -- Strategy 2: scan ALL raw metadata for keys that look path-related
    local ok2, meta = pcall(function()
        return photo:getRawMetadata()
    end)
    if ok2 and type(meta) == 'table' then
        -- First pass: exact key names that are known to hold file paths
        local knownKeys = { 'path', 'filepath', 'fileSystemPath', 'absolutePath', 'rawFilePath', 'filePath' }
        for _, key in ipairs(knownKeys) do
            local val = meta[key]
            if type(val) == 'string' and val ~= '' and val:find('[\\/]') then
                log:info('FolderPathService: got path via known key "' .. key .. '": ' .. val)
                return val
            end
        end

        -- Second pass: any key whose name contains 'path' or 'file' and whose
        -- value looks like an absolute filesystem path
        for k, val in pairs(meta) do
            if type(val) == 'string' and #val > 4 then
                local lk = k:lower()
                if (lk:find('path') or lk:find('file')) and val:find('[\\/]') then
                    log:info('FolderPathService: got path via scanned key "' .. k .. '": ' .. val)
                    return val
                end
            end
        end

        -- Third pass: find any value that looks like an absolute image file path
        for k, val in pairs(meta) do
            if type(val) == 'string' and #val > 5 then
                local isAbsolute = val:sub(1, 1) == '/' or val:match('^[A-Za-z]:[\\/]')
                local hasImageExt = val:lower():match('%.[a-z][a-z][a-z][a-z]?$')
                if isAbsolute and hasImageExt then
                    log:info('FolderPathService: got path via image-ext heuristic key "' .. k .. '": ' .. val)
                    return val
                end
            end
        end
    else
        log:warn('FolderPathService: getRawMetadata() without args failed: ok2=' .. tostring(ok2))
    end

    log:warn('FolderPathService: could not find file path in any metadata key')
    return nil
end

-- Returns the folder hierarchy of a photo as a list of folder name strings,
-- anchored at the closest catalog root folder (if detectable), otherwise
-- falling back to the last 3 path segments.
-- Must be called from within catalog:withReadAccessDo().
function FolderPathService.getFolderPathForPhoto(catalog, photo)
    if not photo then
        log:warn('FolderPathService.getFolderPathForPhoto: photo is nil')
        return nil
    end

    local filePath = getPhotoFilePath(photo)
    log:info('FolderPathService.getFolderPathForPhoto: filePath = ' .. tostring(filePath))

    if not filePath or filePath == '' then
        log:warn('FolderPathService.getFolderPathForPhoto: no file path found')
        return nil
    end

    local folderPath = LrPathUtils.parent(filePath)
    log:info('FolderPathService.getFolderPathForPhoto: folderPath = ' .. tostring(folderPath))

    if not folderPath or folderPath == '' then
        log:warn('FolderPathService.getFolderPathForPhoto: LrPathUtils.parent returned empty')
        return nil
    end

    local allSegments = splitSegments(folderPath)
    log:info('FolderPathService.getFolderPathForPhoto: allSegments count = ' .. tostring(#allSegments))

    if #allSegments == 0 then
        log:warn('FolderPathService.getFolderPathForPhoto: no path segments from ' .. folderPath)
        return nil
    end

    local isWindows = filePath:match('^[A-Za-z]:') ~= nil

    -- Try to find the deepest matching catalog root folder
    local matchedRootPath = nil
    local matchedRootName = nil

    pcall(function()
        local roots = catalog:getFolders() or {}
        log:info('FolderPathService: catalog:getFolders() returned ' .. tostring(#roots) .. ' root(s)')

        for _, folder in ipairs(roots) do
            local rpath = folder:getPath()
            if rpath and rpath ~= '' then
                local rNorm = rpath:gsub('[\\/]+$', '')
                local fNorm = folderPath:gsub('[\\/]+$', '')

                local headLen = #rNorm
                local head = fNorm:sub(1, headLen)
                local nextChar = fNorm:sub(headLen + 1, headLen + 1)

                local headMatches
                if isWindows then
                    headMatches = head:lower() == rNorm:lower()
                else
                    headMatches = head == rNorm
                end

                local isPrefix = headMatches and (
                    #fNorm == headLen or
                    nextChar == '/' or
                    nextChar == '\\'
                )

                if isPrefix then
                    if matchedRootPath == nil or headLen > #matchedRootPath then
                        matchedRootPath = rNorm
                        matchedRootName = folder:getName() or LrPathUtils.leafName(rpath)
                        log:info('FolderPathService: candidate root: ' .. rNorm .. ' name=' .. tostring(matchedRootName))
                    end
                end
            end
        end
    end)

    if matchedRootPath then
        log:info('FolderPathService: using catalog root: ' .. matchedRootPath)
        local relative = folderPath:gsub('[\\/]+$', ''):sub(#matchedRootPath + 1):gsub('^[\\/]+', '')
        local result = { matchedRootName }
        for seg in relative:gmatch('[^\\/]+') do
            if seg ~= '' then
                table.insert(result, seg)
            end
        end
        log:info('FolderPathService: result = ' .. table.concat(result, ' / '))
        return result
    end

    -- Fallback: use last 3 segments to avoid exposing full OS home paths
    log:warn('FolderPathService: no catalog root matched, using last-3-segments fallback')
    local result = {}
    local startIdx = math.max(1, #allSegments - 2)
    for i = startIdx, #allSegments do
        table.insert(result, allSegments[i])
    end
    log:info('FolderPathService: fallback result = ' .. table.concat(result, ' / '))
    return result
end

return FolderPathService
